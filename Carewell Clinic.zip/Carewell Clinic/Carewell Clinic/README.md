# Hospital Management System

* The entire application contains two parts:

1. **Admin Side**: 
* This is controlled by the Hospital Management to allot various patients to their respective hospitals.
* Patients can put up Hospitals in a priority order and the hospitals can accept the needed proposals as well!
* Python Web App has been made for this!

2. **User Side**:
## Doctor Login
* Android and iOS App to allow patients to select which hospital they want to book an appointment to!
* Allows users to know the cost of the treatment before-hand thereby allowing them to use a preference order for the same!  

## Patient Login
* Android and iOS App to allow patients to select which hospital they want to book an appointment to!

## About
* Allows you to book appointments via the Mobile App.

## Documentation for Oak Crest 

### Diagrams to be drawn:
* Class Diagram
* State Diagram
* Use Case Diagrams
* Sequence Diagrams
* Deployment Diagrams

* Use Case Points Diagram

### Classes in the Class Diagram


## To Do:
- [ ] Class Diagrams
- [ ] SIde Bar in Android and iOS App.