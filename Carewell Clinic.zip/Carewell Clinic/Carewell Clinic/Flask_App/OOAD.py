from django.shortcuts import render
from flask import Flask
from flask import abort
from flask import make_response
from flask import request
from flask import render_template
from flask import url_for
from flask import redirect
from firebase import firebase
from admin_application import CreatePatient
from admin_application import Patient
from admin_application import AddDoctor
from admin_application import AddStaff
from admin_application import Doctor
import os
from flask import send_file
from InvoiceGenerator.api import Invoice, Item, Client, Provider, Creator
from InvoiceGenerator.pdf import SimpleInvoice


app = Flask(__name__)
Name = ""

message = ""


@app.route('/', methods=['GET'])
def home():
    return redirect('/patientLogin')


@app.route('/adminActivity', methods=['GET'])
def admin_activity():
    return render_template('admin_activity.html')


@app.route('/doctorActivity', methods=['GET'])
def doctor_activity():
    doctor_id = request.args.get('doctor_id')
    return render_template('doctor_activity.html', token=doctor_id)


@app.route('/patientActivity', methods=['GET'])
def patient_activity():
    token = request.args.get('patient_id')
    return render_template('patient_activity.html', token=token)


@app.route('/staffActivity', methods=['GET'])
def staff_activity():
    return render_template('staff_activity.html')


@app.route('/admin', methods=['GET'])
def admin():
    return render_template('admin.html')


@app.route('/registerPatient', methods=['GET', 'POST'])
def register_patient():
    error = None

    if request.method == 'POST':
        flag = 0

        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/patient', None)
        user_key_list = []
        count = 0

        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        phone = False

        for i in user_key_list:
            if result[i]['username'] == request.form['username']:
                count = count+1
            if result[i]['mobile_number'] == request.form['phone']:
                phone = True

        if request.form['username'] == '' or request.form['password'] == '' or request.form['name'] == '' or request.form['phone'] == '' or request.form['insurance'] == '' or request.form['address'] == '':
            error = "Please fill the entire form"
        else:

            if request.form['password'] == request.form['againPassword'] and count == 0:
                patient = CreatePatient(request.form['username'], request.form['password'], request.form['name'],
                                        request.form['phone'], request.form['insurance'], request.form['address'], 'None')
                flag = 1
                count = 0
        if flag == 1:
            return render_template('patient_register.html', register='true')
        elif request.form['password'] != request.form['againPassword']:
            error = 'Error: both the passwords are not matching'
        elif count >= 1:
            error = 'username already exists'
        elif phone == True:
            error = 'Phone number already exists'
    return render_template('patient_register.html', error=error)


@app.route('/registerDoctor', methods=['GET', 'POST'])
def register_doctor():
    error = None

    if request.method == 'POST':
        flag = 0

        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/doctor', None)
        user_key_list = []
        count = 0

        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['username'] == request.form['username']:
                count = count+1

        if request.form['username'] == '' or request.form['password'] == '' or request.form['name'] == '' or request.form['phone'] == '' or request.form['department'] == '' or request.form['aadhaar'] == '' or request.form['time'] == '':
            error = 'Fill all the details'
        else:

            if request.form['password'] == request.form['againPassword'] and count == 0:
                doctor = AddDoctor(request.form['username'], request.form['password'], request.form['name'],
                                   request.form['phone'], '', request.form['department'], request.form['aadhaar'], request.form['time'], 'true')
                flag = 1
                count = 0
        if flag == 1:
            return render_template('doctor_register.html', register='true')
        elif request.form['password'] != request.form['againPassword']:
            error = 'Error: both the passwords are not matching'
        elif count >= 1:
            error = 'username already exists'
    return render_template('doctor_register.html', error=error)


@app.route('/registerStaff', methods=['GET', 'POST'])
def register_staff():
    error = None

    if request.method == 'POST':
        flag = 0

        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/staff', None)
        user_key_list = []
        count = 0

        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['username'] == request.form['username']:
                count = count+1

        if request.form['username'] == '' or request.form['password'] == '' or request.form['phone'] == '':
            error = "Please fill all the details"
        else:

            if request.form['password'] == request.form['againPassword'] and count == 0:
                doctor = AddStaff(
                    request.form['username'], request.form['password'], request.form['name'], request.form['phone'])
                flag = 1
                count = 0
        if flag == 1:
            return render_template('register_staff.html', register='true')
        elif request.form['password'] != request.form['againPassword']:
            error = 'Error: both the passwords are not matching'
        elif count >= 1:
            error = 'username already exists'
    return render_template('register_staff.html', error=error)


@app.route('/discharge', methods=['GET', 'POST'])
def discharge():
    if request.method == 'POST':
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/patient', None)
        if result == None:
            result = {}
        user_key_list = []
        user_id = ''

        for i in result.keys():
            user_key_list.append(i)
        print(result.keys)
        for i in user_key_list:
            if result[i]['mobile_number'] == request.form['phone']:
                user_id = i

                break
        if user_id == '':
            return render_template('patient_discharge.html', error="Patient phone number is not valid")
        elif request.form['description'] == '' and request.form['admit'] == 'Discharge':
            return render_template('patient_discharge.html', error="Enter patient description")
        else:
            firebase1.patch('/patient/' + user_id,
                            {'status': request.form['admit']})
            if request.form['admit'] == 'Discharge':
                return render_template('patient_report.html', name=result[user_id]['name'], address=result[user_id]['address'], phone=result[user_id]['mobile_number'], description=request.form['description'])
            return render_template('staff_activity.html')

    return render_template('patient_discharge.html')


@app.route('/patientStatus', methods=['GET', 'POST'])
def patient_status():
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/patient', None)
    if result == None:
        result = {}
    user_key_list = []

    lst = []

    for i in result.keys():
        user_key_list.append(i)

    for i in user_key_list:
        if result[i]['status'] != 'None':
            lst.append(result[i])
    return render_template('patient_status.html', patients=lst)


@app.route('/morningSession', methods=['GET', 'POST'])
def morning_session():
    patient_id = request.args.get('patient_id')
    error = None
    lst = []
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/doctor', None)
    result2 = firebase1.get('/patient/' + patient_id + '/bookings', None)

    user_key_list = []

    if result == None:
        result = {}

    if result2 == None:
        result2 = {}

    for i in result.keys():
        user_key_list.append(i)

    book = 'false'

    print(user_key_list)

    class Doctor:
        def __init__(self, name, mobile_number, department, appointments_count, time, employee_number, book):
            self.name = name
            self.mobile_number = mobile_number
            self.department = department
            self.appointments_count = appointments_count
            self.time = time
            self.employee_number = employee_number
            self.book = book

    for i in user_key_list:
        if result[i]['time'] == 'morning' and result[i]['available'] == 'true':
            if result2 != None:
                for j in result2.keys():
                    if result2[j]['doctor_id'] == i:
                        book = 'true'
                        break
            lst.append(Doctor(result[i]['name'], result[i]['mobile_number'], result[i]
                              ['department'], result[i]['appointments_count'], result[i]['time'], result[i]['employee_number'], book))
            print(lst)
            book = 'false'

    return render_template('doctors.html', patient_id=patient_id, result=lst, error=error)


@app.route('/updateDoctor', methods=['GET', 'POST'])
def updateDoctor():
    doctor_id = request.args.get('doctor_id')
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')

    if request.method == 'POST':
        try:
            if request.form['available'] == 'false':
                firebase1.patch('/doctor/' + doctor_id, {
                    'available': request.form['available']
                })
                return render_template('update_doctor.html', message="Doctor has been updated")
            if request.form['available'] == 'true' and request.form['time'] != '':
                firebase1.patch('/doctor/' + doctor_id, {
                    'available': request.form['available'], 'time': request.form['time']
                })
                return render_template('update_doctor.html', message="Doctor has been updated")
            else:
                return render_template('update_doctor.html', message="time is required")
        except:
            return render_template('update_doctor.html', message="time is required")

    return render_template('update_doctor.html')


@app.route('/eveningSession', methods=['GET', 'POST'])
def evening_session():
    patient_id = request.args.get('patient_id')
    error = None
    lst = []
    doctor_id = request.args.get('doctor_id')
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/doctor', None)
    result2 = firebase1.get('/patient/' + patient_id + '/bookings', None)

    user_key_list = []

    if result == None:
        result = {}

    if result2 == None:
        result2 = {}

    for i in result.keys():
        user_key_list.append(i)

    book = 'false'

    print(user_key_list)

    class Doctor:
        def __init__(self, name, mobile_number, department, appointments_count, time, employee_number, book):
            self.name = name
            self.mobile_number = mobile_number
            self.department = department
            self.appointments_count = appointments_count
            self.time = time
            self.employee_number = employee_number
            self.book = book

    for i in user_key_list:
        if result[i]['time'] == 'evening' and result[i]['available'] == 'true':
            if result2 != None:
                for j in result2.keys():
                    if result2[j]['doctor_id'] == i:
                        book = 'true'
                        break
            lst.append(Doctor(result[i]['name'], result[i]['mobile_number'], result[i]
                              ['department'], result[i]['appointments_count'], result[i]['time'], result[i]['employee_number'], book))
            print(lst)
            book = 'false'

    return render_template('doctors.html', patient_id=patient_id, result=lst, error=error)


@app.route('/adminLogin', methods=['GET', 'POST'])
def admin_login():
    error = None
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/admin', None)

    user_key_list = []

    if result == None:
        result = {}

    for i in result.keys():
        user_key_list.append(i)

    if request.method == 'POST':
        flag = 0
        for i in user_key_list:
            if request.form['username'] == str(result[i]['username']) and request.form['password'] == str(result[i]['password']):
                token = i
                flag = 1
                break
        if flag == 1:
            return render_template('admin_activity.html', login='true')
        else:
            error = 'Invalid credentials. Please try again.'
    return render_template('admin_login.html', error=error)


@app.route('/patientLogin', methods=['GET', 'POST'])
def patient_login():
    error = None
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/patient', None)
    user_key_list = []

    if result == None:
        result = {}

    for i in result.keys():
        user_key_list.append(i)

    if request.method == 'POST':
        if request.form['username']=="" and request.form['password']=="":
            error = 'Please enter username and password.'
            return render_template('patient_login.html', error=error)
        elif request.form['username']=="":
            error = 'Please enter username.'
            return render_template('patient_login.html', error=error)
        elif request.form['password']=="":
            error = 'Please enter password.'
            return render_template('patient_login.html', error=error)
        flag = 0
        for i in user_key_list:
            if request.form['username'] == str(result[i]['username']) and request.form['password'] == str(result[i]['password']):
                token = i
                flag = 1
                break
        if flag == 1:
            return render_template('patient_activity.html', name=result[token]['name'], token=token, login='true')

        else:
            error = 'Invalid credentials. Please try again.'
    return render_template('patient_login.html', error=error)


@app.route('/doctors', methods=['GET', 'POST'])
def doctors():
    role = request.args.get('role')
    id_ = request.args.get('id')
    print(id_)
    error = None
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/doctor', None)
    user_key_list = []

    lst = []

    if result == None:
        result = {}

    for i in result.keys():
        user_key_list.append(i)

    for i in user_key_list:
        lst.append(result[i])

    return render_template('doctors.html', result=lst, patient_id=id_, role=role)


@app.route('/bill', methods=['GET', 'POST'])
def bill():
    if request.method == 'POST' and request.form['phone'] != '' and request.form['amount'] != '':
        print(request.form['phone'])

        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/patient', None)
        if result == None:
            result = {}
        user_key_list = []
        user_id = ''
        name = ''

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['mobile_number'] == request.form['phone']:
                user_id = i
                name = result[i]['name'] + '\n' + result[i]['mobile_number']
                break
        if user_id == '':
            return render_template('bill.html', error='patient does not exist')
        if request.form['doctor_amount'] == '' or request.form['doctor_amount'] == '':
            return render_template('bill.html', error='enter the amount')

        os.environ["INVOICE_LANG"] = "en"
        client = Client(name)
        provider = Provider(
            'Carewell Clinic', bank_account='6454-6361-217273', bank_code='2021')
        creator = Creator('Creator Name')
        invoice = Invoice(client, provider, creator)
        invoice.number = user_id
        invoice.add_item(
            Item(1,  request.form['doctor_amount'], description="Doctor charge"))
        invoice.add_item(
            Item(1,  request.form['amount'], description="Clinic charge"))
        invoice.currency = "Rs."
        docu = SimpleInvoice(invoice)
        docu.gen("invoice.pdf", generate_qr_code=False)
        path = "invoice.pdf"

        firebase1.post(
            '/payments', {'amount': request.form['amount'], 'patient': user_id, 'status': 'Pending'})
        return send_file(path, as_attachment=True)
    return render_template('bill.html')


@app.route('/payments', methods=['GET', 'POST'])
def payments():
    me = ''
    me = message
    print(message)
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/patient', None)
    result2 = firebase1.get('/payments', None)

    payments = []

    if result == None:
        result = {}

    if result2 == None:
        result2 = {}

    user_key_list = []

    class Patient:
        def __init__(self, name, mobile, status, id):
            self.name = name
            self.mobile = mobile
            self.status = status
            self.id = id

    for i in result2.keys():
        user_key_list.append([result2[i]['patient'], i])

    for user in user_key_list:
        data = result[user[0]]
        patient = Patient(
            data['name'], data['mobile_number'], result2[user[1]]['status'], user[1])
        payments.append(patient)

    return render_template('payments.html', payments=payments, message=me)


@app.route('/paymentsDone', methods=['GET', 'POST'])
def payments_done():

    _id = request.args.get('payment_id')

    print(_id)

    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')

    firebase1.patch('/payments/' + _id, {'status': "Done"})

    message = "Payment is done"

    return redirect('/payments')


@app.route('/finished', methods=['GET', 'POST'])
def finished():

    doctor_id = request.args.get('doctor_id')

    patient_id = request.args.get('patient_id')

    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')

    result = firebase1.get('/doctor/' + doctor_id + '/appointments', None)

    print(result)
    for i in result.keys():
        if result[i]['patient'] == patient_id:
            firebase1.patch('/doctor/' + doctor_id + '/appointments/' +
                            i, {'status': 'finished'})
    return render_template('patient_appointments.html', doctor_id=doctor_id, finished='true')


@app.route('/book', methods=['GET', 'POST'])
def book():
    error = None
    patient_id = request.args.get('patient_id')
    print(patient_id)
    doctor_id = request.args.get('doctor_id')

    flag = 0
    error = None
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/doctor', None)

    result2 = firebase1.get('/appointments', None)

    mapt = result2['morning_appointments']

    eapt = result2['evening_appointments']

    if mapt >= 24 and result[doctor_id]['time'] == 'morning' and eapt < 24:
        error = "Morning session is full go for the evening session"
    elif eapt >= 24 and result[doctor_id]['time'] == 'evening' and mapt < 24:
        error = "Evening session is full apply for the morning session"

    elif mapt + eapt >= 48:
        error = 'appointment are full for this day apply for the next day'
    else:
        flag = 1

    if flag == 1:
        if result[doctor_id]['time'] == 'morning':
            firebase1.patch('/appointments',
                            {'morning_appointments': mapt + 1})
        elif result[doctor_id]['time'] == 'evening':
            firebase1.patch('/appointments',
                            {'evening_appointments': eapt + 1})
        firebase1.patch('/doctor/' + doctor_id, {
            "appointments_count": result[doctor_id]['appointments_count'] + 1, })

        firebase1.post('/doctor/' + doctor_id + '/appointments', {
            "patient": patient_id,
            "time": result[doctor_id]['time'],
            'status': "unfinished"
        })

        firebase1.post('/patient/' + patient_id + '/bookings', {
            "doctor_id": doctor_id,
        })

        return render_template('patient_activity.html', result=result, patient_id=patient_id, booked='true')

    if flag == 0 and result[doctor_id]['time'] == 'morning':
        lst = []
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/doctor', None)

        user_key_list = []

        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['time'] == 'morning' and result[i]['available'] == 'true':
                lst.append(result[i])

        return render_template('doctors.html', result=lst, patient_id=patient_id, error=error)
    else:
        lst = []
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/doctor', None)

        user_key_list = []

        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['time'] == 'evening' and result[i]['available'] == 'true':
                lst.append(result[i])

        return render_template('doctors.html', result=lst, patient_id=patient_id, error=error)


@app.route('/doctorLogin', methods=['GET', 'POST'])
def doctor_login():
    error = None
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/doctor', None)
    user_key_list = []

    if result == None:
        result = {}

    for i in result.keys():
        user_key_list.append(i)

    if request.method == 'POST':
        flag = 0
        for i in user_key_list:
            if request.form['username'] == str(result[i]['username']) and request.form['password'] == str(result[i]['password']):
                token = i
                flag = 1
                break
        if flag == 1:
            return render_template('doctor_activity.html', name=result[token]['name'], token=token,  login='true')
        else:
            error = 'Invalid credentials. Please try again.'
    return render_template('doctor_login.html', error=error)


@app.route('/staffLogin', methods=['GET', 'POST'])
def staff_login():
    error = None
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/staff', None)
    user_key_list = []

    if result == None:
        result = {}

    for i in result.keys():
        user_key_list.append(i)

    if request.method == 'POST':
        flag = 0
        for i in user_key_list:
            if request.form['username'] == str(result[i]['username']) and request.form['password'] == str(result[i]['password']):
                token = i
                flag = 1
                break
        if flag == 1:
            return render_template('staff_activity.html', login='true')
        else:
            error = 'Invalid credentials. Please try again.'
    return render_template('staff_login.html', error=error)


@app.route('/patientAppointments', methods=['GET', 'POST'])
def patient_appointments():
    error = None
    lst = []
    doctor_id = request.args.get('doctor_id')
    firebase1 = firebase.FirebaseApplication(
        'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
    result = firebase1.get('/doctor', None)

    result2 = firebase1.get('/patient', None)

    if result == None:
        result = {}

    class Patient:
        def __init__(self, _id, name, mobile, insurance, address, time, status) -> None:
            self.id = _id
            self.name = name
            self.mobile = mobile
            self.insurance = insurance
            self.address = address
            self.time = time
            self.status = status

    if result[doctor_id]['appointments_count'] != 0:

        for patient in result[doctor_id]['appointments']:
            data = result2[result[doctor_id]
                           ['appointments'][patient]['patient']]
            print(data)
            patient = Patient(result[doctor_id]
                              ['appointments'][patient]['patient'], data['name'], data['mobile_number'], data['insurance'],
                              data['address'], result[doctor_id]['appointments'][patient]['time'], result[doctor_id]['appointments'][patient]['status'])

            lst.append(patient)

    return render_template('patient_appointments.html', patients=lst, doctor_id=doctor_id)


@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None

    if request.method == 'POST':
        flag = 0

        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/patient', None)
        user_key_list = []
        count = 0
        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['username'] == request.form['username']:
                count = count+1

        if request.form['password'] == request.form['againPassword'] and count == 0:
            firebase1 = firebase.FirebaseApplication(
                'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
            result = firebase1.post('/patient', {
                "username": request.form['username'],
                "password": request.form['password'],
                "name": request.form['name']
            })
            flag = 1
            count = 0
        if flag == 1:
            return render_template('patient_login.html')
        elif request.form['password'] != request.form['againPassword']:
            error = 'Error: both the passwords are not matching'
        elif count >= 1:
            error = 'username already exists'
    return render_template('register.html', error=error)


@app.route('/searchDoctor', methods=['GET', 'POST'])
def searchDoctor():
    error = None
    if request.method == 'POST':
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/doctor', None)
        user_key_list = []
        flag = 0

        if result == None:
            result = {}

        for i in result.keys():
            user_key_list.append(i)

        for i in user_key_list:
            if result[i]['mobile_number'] == request.form['mobile']:
                name = result[i]['name']
                employee_id = result[i]['employee_number']
                department = result[i]['department']
                phone = result[i]['mobile_number']
                username = result[i]['username']
                flag = 1
                user_key_list = []

        if flag == 1:
            return render_template('displayDoctor.html', name=name, employee_id=employee_id, department=department, phone=phone, username=username)

        if flag == 0:
            error = "Invalid Mobile number"

    return render_template('searchDoctor.html', error=error)


@app.route('/searchPatient', methods=['GET', 'POST'])
def searchPatient():
    error = None
    if request.method == 'POST':
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/patient', None)
        user_key_list = []
        flag = 0
        for i in result.keys():
            user_key_list.append(i)

        print(result)

        for i in user_key_list:
            if result[i]['mobile_number'] == request.form['mobile']:
                name = result[i]['name']
                file_number = result[i]['file_number']
                phone = result[i]['mobile_number']
                address = result[i]['address']
                insurance = result[i]['insurance']
                username = result[i]['username']
                flag = 1
                user_key_list = []

        if flag == 1:
            return render_template('displayPatient.html', name=name, file_number=file_number, phone=phone, address=address, insurance=insurance, username=username)

        if flag == 0:
            error = "Invalid Mobile Number"

    return render_template('searchPatient.html', error=error)


# Page yet to be done
@app.route('/appointments', methods=['GET', 'POST'])
def appointments():
    error = None
    if request.method == 'POST':
        oldstr = request.form['email_id']
        email_id = oldstr.replace(".", "")
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/aimananees@gmailcom', None)
        user_key_list = []
        for i in result.keys():
            user_key_list.append(i)
        flag = 0
        total_list = []
        for i in user_key_list:
            # individual_list=[]
            doctorName = result[i]['doctorName']
            # individual_list.append(doctorName)
            time = result[i]['time']
            # individual_list.append(time)
            # total_list.append(individual_list)
            flag = 1

        if flag == 1:
            return render_template('displayAppointments.html', doctorName=doctorName, time=time)
        else:
            error = "No Appointments"
    return render_template('appointments.html', error=error)

# Page yet to be done


@app.route('/schedule', methods=['GET', 'POST'])
def schedule():
    error = None
    if request.method == 'POST':
        oldstr = request.form['email_id']
        email_id = oldstr.replace(".", "")
        firebase1 = firebase.FirebaseApplication(
            'https://hospital-management-b9a17-default-rtdb.firebaseio.com/')
        result = firebase1.get('/aiman@emailcom', None)
        user_key_list = []
        for i in result.keys():
            user_key_list.append(i)
        flag = 0
        total_list = []
        for i in user_key_list:
            individual_list = []
            patientName = result[i]['patientName']
            # individual_list.append(patientName)
            patient_file_number = result[i]['patient_file_number']
            # individual_list.append(patient_file_number)
            patient_insurance = result[i]['patient_insurance']
            # individual_list.append(patient_insurance)
            time = result[i]['time']
            # individual_list.append(time)
            # total_list.append(individual_list)
            flag = 1

        if flag == 1:
            return render_template('displaySchedule.html', patientName=patientName, time=time)
        else:
            error = "No Schedule"
    return render_template('schedule.html', error=error)


if __name__ == '__main__':
    app.run(debug=True, threaded=True)
