@app.route('/',methods=['GET'])
def home():
	return redirect('/welcome')